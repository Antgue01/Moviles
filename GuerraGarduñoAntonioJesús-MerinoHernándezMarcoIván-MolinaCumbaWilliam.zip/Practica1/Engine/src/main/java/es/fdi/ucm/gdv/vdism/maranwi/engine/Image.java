package es.fdi.ucm.gdv.vdism.maranwi.engine;

public interface Image {
    int getWidth();
    int getHeigth();
}
