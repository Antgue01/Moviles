package es.fdi.ucm.gdv.vdism.maranwi.engine;

public interface Engine {
    /** Obtener referencia Graphics */
    Graphics getGraphics();
    /** Obtener referencia Input */
    Input getInput();
}
