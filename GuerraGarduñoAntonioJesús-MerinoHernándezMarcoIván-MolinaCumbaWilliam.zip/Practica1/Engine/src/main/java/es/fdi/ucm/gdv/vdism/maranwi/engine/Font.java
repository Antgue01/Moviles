package es.fdi.ucm.gdv.vdism.maranwi.engine;

public interface Font {
    int getSize();
    boolean getIsBold();
}
