package es.fdi.ucm.gdv.vdism.maranwi.engine;

public interface Color {
    int getRGBA();
    int getRed();
    int getGreen();
    int getBlue();
    int getAlpha();
}
