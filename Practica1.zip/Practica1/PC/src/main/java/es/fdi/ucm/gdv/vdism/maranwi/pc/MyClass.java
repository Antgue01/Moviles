package es.fdi.ucm.gdv.vdism.maranwi.pc;

public class MyClass {

    public static void main(String[] args){
        System.out.println("ey que pasa");

    }

}